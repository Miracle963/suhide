# setup

RAMDISK=$1
UIDFILE=/data/adb/suhide.uid
PRELOAD32=suhide32.so
PRELOAD64=suhide64.so
PRELOADDEF=$PRELOAD32
SYSTEMLIB=/system/lib
BITS64=false
if [ -d "/system/lib64" ]; then
  SYSTEMLIB=/system/lib64
  PRELOADDEF=$PRELOAD64
  BITS64=true
fi

# check files

if [ ! -d "/data/adb" ]; then exit 1; fi
if [ ! -f "/data/adb/$PRELOAD32" ]; then exit 1; fi
# don't check for 64, it won't be there on 32, but PRELOADDEF will be set to it on 64
if [ ! -f "/data/adb/$PRELOADDEF" ]; then exit 1; fi

# patch ramdisk

# --- adjust SELinux policies

LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK sepolicy /tmp/sepolicy
if [ -f "/tmp/sepolicy" ]; then
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/supolicy --file /tmp/sepolicy /tmp/sepolicy.patched "allow { zygote shell } { rootfs adb_data_file } dir search" "allow { zygote shell } { rootfs adb_data_file } file { getattr open read execute }" "allow zygote fs_type filesystem unmount" "allow domain { rootfs adb_data_file } file execute"
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 644 sepolicy /tmp/sepolicy.patched
  rm /tmp/sepolicy
  rm /tmp/sepolicy.patched
fi

# --- create PATH without su

LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK init.environ.rc /tmp/init.environ.rc
EXPORT_PATH=
if [ -f "/tmp/init.environ.rc" ]; then
  EXPORT_PATH=$(cat /tmp/init.environ.rc | grep "export PATH " | sed 's/export PATH//g' | tr -d " " | sed 's/\/su\/bin://g' | sed 's/:\/su\/xbin//g')
  rm /tmp/init.environ.rc
fi

# --- patch zygote service launches

for file in init.zygote.rc init.zygote32.rc init.zygote64.rc init.zygote64_32.rc; do
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK $file /tmp/$file
  if [ -f "/tmp/$file" ]; then
    sed -i "/\/system\/bin\/app_process\ /a\ \ \ \ setenv LD_PRELOAD /sbin/$PRELOADDEF" /tmp/$file
    sed -i "/\/system\/bin\/app_process32\ /a\ \ \ \ setenv LD_PRELOAD /sbin/$PRELOAD32" /tmp/$file
    sed -i "/\/system\/bin\/app_process64\ /a\ \ \ \ setenv LD_PRELOAD /sbin/$PRELOAD64" /tmp/$file
    if [ ! -z "$EXPORT_PATH" ]; then
      sed -i "/\/system\/bin\/app_process/a\ \ \ \ setenv PATH $EXPORT_PATH" /tmp/$file
    fi
    LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 750 $file /tmp/$file
    rm /tmp/$file
  fi
done

# --- place files

LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 700 sbin/$PRELOAD32 /data/adb/$PRELOAD32
if ($BITS64); then
    LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 700 sbin/$PRELOAD64 /data/adb/$PRELOAD64
fi

# generate default UIDs

if [ ! -f "$UIDFILE" ]; then
  for i in com.google.android.gms; do
    for j in `ls /data/data | grep $i`; do
      UID=$(ls -ldn /data/data/$j | tr -s " " | cut -d " " -f 3);
      if (! cat $UIDFILE 2>/dev/null | grep "^$UID$" >/dev/null); then
        echo "$UID" >> $UIDFILE
      fi
    done
  done
fi

exit 0