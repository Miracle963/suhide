RAMDISK=$1
UIDFILE=/data/adb/suhide.uid
PRELOAD32=/data/adb/suhide32.so
PRELOAD64=/data/adb/suhide64.so
PRELOADDEF=$PRELOAD
SYSTEMLIB=/system/lib
if [ -d "/system/lib64" ]; then
  SYSTEMLIB=/system/lib64
  PRELOADDEF=$PRELOAD64
fi

LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK sepolicy /tmp/sepolicy
if [ -f "/tmp/sepolicy" ]; then
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/supolicy --file /tmp/sepolicy /tmp/sepolicy.patched "allow { zygote shell } { rootfs adb_data_file } dir search" "allow { zygote shell } { rootfs adb_data_file } file { getattr open read execute }" "allow zygote fs_type filesystem unmount"
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 644 sepolicy /tmp/sepolicy.patched
  rm /tmp/sepolicy
  rm /tmp/sepolicy.patched
fi

LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK init.environ.rc /tmp/init.environ.rc
EXPORT_PATH=
if [ -f "/tmp/init.environ.rc" ]; then
  EXPORT_PATH=$(cat /tmp/init.environ.rc | grep "export PATH " | sed 's/export PATH//g' | tr -d " " | sed 's/\/su\/bin://g' | sed 's/:\/su\/xbin//g')
  rm /tmp/init.environ.rc
fi

for file in init.zygote.rc init.zygote32.rc init.zygote64.rc init.zygote64_32.rc; do
  LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-extract $RAMDISK $file /tmp/$file
  if [ -f "/tmp/$file" ]; then
    sed -i "/\/system\/bin\/app_process\ /a\ \ \ \ setenv LD_PRELOAD $PRELOADDEF" /tmp/$file
    sed -i "/\/system\/bin\/app_process32\ /a\ \ \ \ setenv LD_PRELOAD $PRELOAD32" /tmp/$file
    sed -i "/\/system\/bin\/app_process64\ /a\ \ \ \ setenv LD_PRELOAD $PRELOAD64" /tmp/$file
    if [ ! -z "$EXPORT_PATH" ]; then
      sed -i "/\/system\/bin\/app_process/a\ \ \ \ setenv PATH $EXPORT_PATH" /tmp/$file
    fi
    LD_LIBRARY_PATH=$SYSTEMLIB /su/bin/sukernel --cpio-add $RAMDISK $RAMDISK 750 $file /tmp/$file
    rm /tmp/$file
  fi
done

if [ ! -f "$UIDFILE" ]; then
  for i in com.android. com.google.; do
    for j in `ls /data/data | grep $i`; do
      UID=$(ls -ldn /data/data/$j | tr -s " " | cut -d " " -f 3);
      if (! cat $UIDFILE 2>/dev/null | grep "$UID" >/dev/null); then
        echo "$UID" >> $UIDFILE
      fi
    done
  done
fi

exit 0